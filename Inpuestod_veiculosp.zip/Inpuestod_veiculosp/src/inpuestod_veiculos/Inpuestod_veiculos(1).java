
package inpuestod_veiculos;
public class Inpuestod_veiculos {
    public static void main(String[] args) {
     
    }
    
}
