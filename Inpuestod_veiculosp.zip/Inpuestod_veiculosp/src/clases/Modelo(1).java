/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

    public class Modelo
{
    //-----------------------------------------------------------------
    // Atributos
    //-----------------------------------------------------------------

    /** Año del modelo */
    private String anio;
    /** Precio del vehículo de este modelo */
    private double precio;

    //-----------------------------------------------------------------
    // Constructores
    //-----------------------------------------------------------------

    /**
     * Crea un modelo con el año y su precio.
     * @param elAnio Año del modelo.
     * @param elPrecio Precio de un vehículo de este modelo.
     */
    public Modelo( String elAnio, double elPrecio )
    {
        anio = elAnio;
        precio = elPrecio;
    }

    //-----------------------------------------------------------------
    // Métodos
    //-----------------------------------------------------------------

    /**
     * Retorna el año del modelo.
     * @return año.
     */
    public String darAnio( )
    {
        return anio;
    }

    /**
     * Retorna el precio del modelo.
     * @return precio.
     */
    public double darPrecio( )
    {
        return precio;
    }
}
    

