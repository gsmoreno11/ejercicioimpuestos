


import java.awt.event.ItemEvent;
import javax.swing.DefaultComboBoxModel;
public class principal extends javax.swing.JFrame {

    public principal() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    
    public String[] getAño(String marca)
    {
     String [] año = new String [6];
     if (marca.equalsIgnoreCase("AUDI"))
     {
         año[0]="SELECCIONAR";
         año[1]="2009";
         año[2]="2011";
         año[3]="2018";
         año[4]="2019";
         año[5]="2005";           
     }
      if (marca.equalsIgnoreCase("BAIC"))
     {
         año[0]="SELECCIONAR";
         año[1]="2005";
         año[2]="2006";
         año[3]="2011";
         año[4]="2015";
         año[5]="2018";              
     }
      if (marca.equalsIgnoreCase("BMW"))
     {
         año[0]="SELECCIONAR";
         año[1]="2009";
         año[2]="2011";
         año[3]="2017";
         año[4]="2018";
         año[5]="2020";        
     }
       if (marca.equalsIgnoreCase("BRILLANCE"))
     {
         año[0]="SELECCIONAR";
         año[1]="2010";
         año[2]="2011";
         año[3]="2015";
         año[4]="2018";
         año[5]="2021";
          
     }
        if (marca.equalsIgnoreCase("BYD"))
     {
         año[0]="SELECCIONAR";
         año[1]="2010";
         año[2]="2015";
         año[3]="2018";
         año[4]="2019";
         año[5]="2020";           
     }
        return año;
        
 }
      public String[] getModelo(String marca)
    {
     String [] modelo = new String [6];
     
     if (marca.equalsIgnoreCase("AUDI"))
     {
         modelo[0]="SELECCIONAR";
         modelo[1]="A4";
         modelo[2]="A5";
         modelo[3]="A6";    
     }
      if (marca.equalsIgnoreCase("BAIC"))
     {
         modelo[0]="SELECCIONAR";
         modelo[1]="BJ06C"; 
           modelo[1]="BJ06C"; 
             modelo[1]="BJ06C"; 
     }
      if (marca.equalsIgnoreCase("BMW"))
     {
         modelo[0]="SELECCIONAR";
         modelo[1]="114I";
         modelo[2]="118I";
         modelo[3]="220I";
           
     }
       if (marca.equalsIgnoreCase("BRILLANCE"))
     {
         modelo[0]="SELECCIONAR";
         modelo[1]="H530";
         modelo[2]="V5";
           modelo[1]="BJ06C"; 
         
     }
        if (marca.equalsIgnoreCase("BYD"))
     {
         modelo[0]="SELECCIONAR";
         modelo[1]="F-0";
         modelo[2]="F3";
         modelo[3]="QIN";
               
     }
        return modelo;
        
 }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Marca = new javax.swing.JComboBox<>();
        Año = new javax.swing.JComboBox<>();
        modelo = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Marca.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar", "AUDI", "BAIC", "BMW", "BRILLANCE", "BYD" }));
        Marca.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                MarcaItemStateChanged(evt);
            }
        });
        Marca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MarcaActionPerformed(evt);
            }
        });

        Año.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AñoActionPerformed(evt);
            }
        });

        modelo.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                modeloItemStateChanged(evt);
            }
        });

        jLabel1.setText("Marca");

        jLabel2.setText("Año");

        jLabel3.setText("Modelo");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(modelo, 0, 66, Short.MAX_VALUE)
                    .addComponent(Año, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Marca, javax.swing.GroupLayout.Alignment.TRAILING, 0, 1, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Marca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(31, 31, 31)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Año, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(33, 33, 33)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(modelo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addContainerGap(55, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(888, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(183, 183, 183)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(255, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void MarcaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_MarcaItemStateChanged
     if(evt.getStateChange()==ItemEvent.SELECTED){
        if(this.Marca.getSelectedIndex() >0){
            this.Año.setModel(new DefaultComboBoxModel(this.getAño(this.Marca.getSelectedItem().toString() )));
            
        } 
     }
     if(evt.getStateChange()==ItemEvent.SELECTED){
        if(this.Marca.getSelectedIndex() >0){
            this.modelo.setModel(new DefaultComboBoxModel(this.getModelo(this.Marca.getSelectedItem().toString() )));
            
        } 
     }   
    }//GEN-LAST:event_MarcaItemStateChanged

    private void modeloItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_modeloItemStateChanged
   
  
    }//GEN-LAST:event_modeloItemStateChanged

    private void MarcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MarcaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MarcaActionPerformed

    private void AñoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AñoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_AñoActionPerformed
 
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new principal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> Año;
    private javax.swing.JComboBox<String> Marca;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JComboBox<String> modelo;
    // End of variables declaration//GEN-END:variables
}
