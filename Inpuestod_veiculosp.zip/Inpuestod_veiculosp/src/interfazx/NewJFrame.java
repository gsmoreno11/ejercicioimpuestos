package interfazx;




import java.awt.event.ItemEvent;
import javax.swing.DefaultComboBoxModel;

/**
 *
 * @author garym
 */
public class NewJFrame extends javax.swing.JFrame {
String a;
String b;
String c;
int t,y,u;
int resultado;
int prontopagoaux=(resultado*10)/100; ;
int serviciopublicoaux=(resultado*8)/100; ;
int trasladodecuentaaux=(resultado*3)/100;;
int resultadoinouesto;
                 
public String[] getMarca(String marca){
         
String[]modelo=new String[6];
            
if(marca.equalsIgnoreCase("BYD")){
modelo[0]="Seleccionar";
modelo[1]="F0";
modelo[2]="Flyer";
modelo[3]="F2";
modelo[4]="F3";
a="13000000";
t=100000;
if(modelo[1]=="F0"){
b="10000000";
y=30000;
           }
if(modelo[2]=="Flyer"){
b="2";
y=25000;               
}
if(modelo[3]=="F2"){
 b="3";
y=45000;
   }
 if(modelo[3]=="F3"){
 b="10000000";
 y=25000;           
           }
        }
if(marca.equalsIgnoreCase("cadillac")){
 modelo[0]="Seleccionar";
 modelo[1]="ATS";   
 modelo[2]="CT6";
 modelo[3]="Escalade";
 modelo[4]="SRX";
a="20000000";
t=130000;
if(modelo[1]=="ATS"){
 b="1001";
 y=43000;
                }
 if(modelo[2]=="CT6"){
 b="102";
  y=43000;
  }
 if(modelo[3]=="Escalade"){
 b="103";
 y=43000;
               }
if(modelo[4]=="SRX"){
b="1004";
y=43000;
                }
           }
            
if(marca.equalsIgnoreCase("Audi")){
modelo[0]="Seleccionar"; modelo[1]="34";
            
modelo[2]="543A";
modelo[3]="245A";
modelo[4]="23B";
a="2222222";
t=190000;
if(modelo[1]=="34"){
 b="10012";
 y=43000;
                }
 if(modelo[2]=="543A"){
 b="1023";
 y=43000;
                }  
 if(modelo[3]=="245A"){
 b="1035";
 y=43000;
               }
if(modelo[4]=="23B"){
 b="10047";
 y=43000;
                }
            
        }
          if(marca.equalsIgnoreCase("Alpine")){
            modelo[0]="Seleccionar";
             modelo[1]="cv";
              modelo[2]="252";
               modelo[3]="298";
                modelo[4]="301";
            a="10323883";
            t=200000;
             if(modelo[1]=="CV"){
               b="1001001";
                     y=43000;
                }
                if(modelo[2]=="252"){
               b="102002";
                     y=43000;
                }
               if(modelo[3]=="298"){
               b="103003";
                     y=43000;
               }
                if(modelo[4]=="301"){
               b="1004004";
                     y=43000;

                }
        }
          if(marca.equalsIgnoreCase("BMW")){
            modelo[0]="Seleccionar";
             modelo[1]="Caupe";
              modelo[2]="Taurer";
               modelo[3]="Cabrio";
                modelo[4]="coupe";
                a="23843829";
                t=1300000;
                
                 if(modelo[1]=="Caupe"){
               b="10011";
                     y=43000;
                }
                if(modelo[2]=="Taurer"){
               b="1022";
                     y=43000;
                }
               if(modelo[3]=="Cabrio"){
               b="1033";
                     y=43000;
               }
                if(modelo[4]=="coupe"){
               b="10044";
                     y=43000;

                }
          }
    return modelo;
     }
          public String[] getMarca1(String marca){
         
        String[]linea=new String[6];
            
        if(marca.equalsIgnoreCase("BYD")){
            linea[0]="Seleccionar";
             linea[1]="2009";
              linea[2]="2011";
               linea[3]="2013";
                linea[4]="2017";
                        
    if(linea[1]=="2009"){
               c="10043568";
               u=100000;
               
           }
     if(linea[2]=="2011"){
               c="20769843";
                u=100000;
               
           }
      if(linea[3]=="2013"){
               c="87405602";
                u=100000;
               
           }
       if(linea[3]=="2017"){
               c="28394991";
                u=100000;
              
           }
        }
         if(marca.equalsIgnoreCase("cadillac")){
            linea[0]="Seleccionar";
             linea[1]="2011";
              
              linea[2]="2015";
               linea[3]="2016";
                linea[4]="2018";
                if(linea[1]=="2011"){
               c="1001";
                u=100000;
                }
                if(linea[2]=="2015"){
               c="102";
                u=100000;
                }
               if(linea[3]=="2016"){
               c="103";
                u=100000;
               }
                if(linea[4]=="2018"){
               c="1004";
                u=100000;

                }
           }
            
                  if(marca.equalsIgnoreCase("BYD")){
            linea[0]="Seleccionar";
             linea[1]="2009";
              linea[2]="2015";
               linea[3]="2018";
                linea[4]="2021";
                 if(linea[1]=="2009"){
               c="10012";
                u=100000;
                }
                if(linea[2]=="2015"){
               c="1023";
                u=100000;
                }
               if(linea[3]=="2018"){
               c="1035";
               u=100000;
               }
                if(linea[4]=="2021"){
               c="10047";
                u=100000;

                }
            
        }
          if(marca.equalsIgnoreCase("Alpine")){
            linea[0]="Seleccionar";
             linea[1]="2005";
              linea[2]="2006";
               linea[3]="2007";
                linea[4]="2008";
             if(linea[1]=="2005"){
               c="1001001";
                u=100000;
                }
                if(linea[2]=="2006"){
               c="102002";
                u=100000;
                }
               if(linea[3]=="2007"){
               c="103003";
                u=100000;
               }
                if(linea[4]=="2008"){
               c="1004004";
                u=100000;

                }
        }
          if(marca.equalsIgnoreCase("BMW")){
            linea[0]="Seleccionar";
             linea[1]="2010";
              linea[2]="2011";
               linea[3]="2012";
                linea[4]="2013";
                 if(linea[1]=="2010"){
               c="10011";
                u=100000;
                }
                if(linea[2]=="2011"){
               c="c1022";
                u=100000;
                }
               if(linea[3]=="2012"){
               c="1033";
                u=100000;
               }
                if(linea[4]=="2013"){
               c="10044";
                u=100000;

                }
          }
    return linea;
     }
        /*  String a;
          public String getMarca(){
                 String modelo;
        if(!marcatxm.equals("BYM")){
            
            a="PAPA";
        }
            else{
            
            a="MAMA";
        }
        return a;
        
 }
 */
    public NewJFrame() {
        initComponents();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        marcatxm = new javax.swing.JComboBox();
        modelotxm = new javax.swing.JComboBox();
        lineatxm = new javax.swing.JComboBox();
        valorxtm = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        prontopago = new javax.swing.JCheckBox();
        serviciopublico = new javax.swing.JCheckBox();
        trasladodecuenta = new javax.swing.JCheckBox();
        cal = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        txresultado = new javax.swing.JTextField();
        tximpuestototal = new javax.swing.JTextField();
        tximpuestopagar = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();

        jButton2.setText("valor neto");

        jButton3.setText("valor final");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Calculadora de Impuestos de Carros");

        jLabel3.setText("Marca");

        jLabel5.setText("Modelo");

        jLabel4.setText("Linea");

        jLabel6.setText("valor");

        marcatxm.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Seleccionar", "BYD", "Cadillac", "Audi", "Alpine", "BMW" }));
        marcatxm.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                marcatxmItemStateChanged(evt);
            }
        });
        marcatxm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                marcatxmActionPerformed(evt);
            }
        });

        valorxtm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                valorxtmActionPerformed(evt);
            }
        });

        jLabel7.setText("Descuento");

        prontopago.setText("Pronto Pago");
        prontopago.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prontopagoActionPerformed(evt);
            }
        });

        serviciopublico.setText("Servicio Publico");
        serviciopublico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                serviciopublicoActionPerformed(evt);
            }
        });

        trasladodecuenta.setText("Traslado de Descuento");
        trasladodecuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                trasladodecuentaActionPerformed(evt);
            }
        });

        cal.setText("Calcular");
        cal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                calActionPerformed(evt);
            }
        });

        jLabel8.setText("valores de Impuesto");

        jButton4.setText("Salir");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setText("Ingresar");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabel2.setText("valor del carro");

        jLabel9.setText("valor del impuesto neto");

        jLabel10.setText("valor de impuesto a pagar");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel1))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(84, 84, 84)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addGap(18, 18, 18)
                                        .addComponent(valorxtm))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addGap(57, 57, 57)
                                        .addComponent(lineatxm, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addGap(48, 48, 48)
                                        .addComponent(modelotxm, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addGap(53, 53, 53)
                                        .addComponent(marcatxm, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                        .addGap(32, 32, 32)
                        .addComponent(jButton5))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(95, 95, 95)
                                .addComponent(jLabel8))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(trasladodecuenta)
                                .addGap(51, 51, 51)
                                .addComponent(cal))
                            .addComponent(serviciopublico)
                            .addComponent(prontopago)
                            .addComponent(jLabel7)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(33, 33, 33)
                                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(55, 55, 55)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txresultado)
                                .addComponent(tximpuestopagar, javax.swing.GroupLayout.DEFAULT_SIZE, 85, Short.MAX_VALUE))
                            .addComponent(tximpuestototal, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(34, 34, 34)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(jLabel1)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(113, 113, 113)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lineatxm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addGap(25, 25, 25)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(valorxtm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton5)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(marcatxm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(25, 25, 25)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(modelotxm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(36, 36, 36)
                .addComponent(jLabel7)
                .addGap(18, 18, 18)
                .addComponent(prontopago)
                .addGap(18, 18, 18)
                .addComponent(serviciopublico)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(trasladodecuenta)
                    .addComponent(cal))
                .addGap(35, 35, 35)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txresultado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tximpuestototal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tximpuestopagar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addComponent(jButton4)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void marcatxmItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_marcatxmItemStateChanged

        if(evt.getStateChange()==ItemEvent.SELECTED)
      {
          if(this.marcatxm.getSelectedIndex()>0)
          {
             this.modelotxm.setModel(new DefaultComboBoxModel(this.getMarca(this.marcatxm.getSelectedItem().toString())));
          }
          
      }
          if(evt.getStateChange()==ItemEvent.SELECTED)
      {
          if(this.marcatxm.getSelectedIndex()>0)
          {
             this.lineatxm.setModel(new DefaultComboBoxModel(this.getMarca1(this.marcatxm.getSelectedItem().toString())));
          }
              
      }
           
    }//GEN-LAST:event_marcatxmItemStateChanged

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void valorxtmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_valorxtmActionPerformed

    }//GEN-LAST:event_valorxtmActionPerformed

    private void marcatxmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_marcatxmActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_marcatxmActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
int al;
int al2;
int al3;
String bn;
al=Integer.parseInt(a);
al2=Integer.parseInt(b);
al3=Integer.parseInt(c);
 resultado=al+al2+al3;
 resultadoinouesto=t+y+u;
bn=Integer.toString(resultado);
        System.out.println(al);
        System.out.println(al2);


        valorxtm.setText(bn);        // TODO add your handling code here:
        
    }//GEN-LAST:event_jButton5ActionPerformed

    private void prontopagoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prontopagoActionPerformed

        // TODO add your handling code here:
    }//GEN-LAST:event_prontopagoActionPerformed

    private void serviciopublicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_serviciopublicoActionPerformed
 
    }//GEN-LAST:event_serviciopublicoActionPerformed
    
    private void trasladodecuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_trasladodecuentaActionPerformed

    }//GEN-LAST:event_trasladodecuentaActionPerformed

    private void calActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_calActionPerformed
                   int vl = 0 ;
       
        if(prontopago.isSelected()){
       vl=resultadoinouesto-(resultadoinouesto*10/100);
      
   }
     
        if(serviciopublico.isSelected()){
       vl=resultadoinouesto-(resultadoinouesto*5/100);
   
    }  
       
        if (trasladodecuenta.isSelected()){
           vl=resultadoinouesto-(resultadoinouesto*3/100); 
        }
               txresultado.setText("" +resultado);
               tximpuestototal.setText(" " +resultadoinouesto);
               tximpuestopagar.setText(" " +vl);
    }//GEN-LAST:event_calActionPerformed

   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewJFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cal;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JComboBox lineatxm;
    private javax.swing.JComboBox marcatxm;
    private javax.swing.JComboBox modelotxm;
    private javax.swing.JCheckBox prontopago;
    private javax.swing.JCheckBox serviciopublico;
    private javax.swing.JCheckBox trasladodecuenta;
    private javax.swing.JTextField tximpuestopagar;
    private javax.swing.JTextField tximpuestototal;
    private javax.swing.JTextField txresultado;
    private javax.swing.JTextField valorxtm;
    // End of variables declaration//GEN-END:variables
}
